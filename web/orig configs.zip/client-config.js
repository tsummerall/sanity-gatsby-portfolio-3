module.exports = {
  sanity: {
    projectId: process.env.GATSBY_SANITY_PROJECT_ID || 'n6i4f16f',
    dataset: process.env.GATSBY_SANITY_DATASET || 'production'
  }
}
